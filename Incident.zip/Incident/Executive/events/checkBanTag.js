let sunucuayar = require("../models/sunucuayar");
let conf = client.ayarlar
module.exports = async client => { 


    
}