const settings = {
	"MongoDB": "mongodb+srv://owsla:15271!Ferhat@owsla.m4zgt.mongodb.net/incident?retryWrites=true&w=majority",

    "commandChannel": [],
    "taglıAlım": false,

    "onsekizatilacakoda": "",
    "onsekizodalar": [],

    "sorunCozucu": [],

    "terapist": [],

    "basvuruLog": "başvuru_log",

    "chatMesajı": "-member-, Aramıza hoş geldiniz! Rol seçim odalarından rolleriniz almayı unutmayın iyi eğlenceler.",

    "TAG_SYSTEM_CHANNEL": "828654156671090708",
    "YETKI_VER_LOG": "828654176396640276",
    "CEZA_PUAN_KANAL": "828654188723437618",
    "CEZA_PUAN_SYSTEM": true,

    "MODERASYON": "ODI4NjUwODYzMTkwMzQzNzIw.YGsrQQ.OxzWgRIkno6AhhmugYUiiEvvQjs", // mod botu
    "STATS": "ODI4NjUwOTcxNzY4ODE1Njk2.YGsrWw.DhYyQuzjbe9oux0M0-3b70EO2tE", // stat
    "EXECUTIVE": "ODI4NjUwOTE0MjY4MzE1Njc5.YGsrTQ.4OFdrRCZjKa7-re4KnmHAhN9lKc", // yönetim
    "LOG": "ODI4NjUxMTMwNDYzNTg0MzA3.YGsrgQ.NbGKYk47PRAiMcd1kKA-gO4T4Ko", // log botu
    "ASYNC": "ODI4NjUxMDE1NTk0OTY3MTAw.YGsrZQ.ghXGJhrorSixK8-RFY5HPezohqM", // async botu

    "prefix": [".","!"],
    "botSesID": "813907911448985621",
    "sunucuId": "786545188897161286",
    "sahip": ["712282397995171871", "460903660256362523"],
    "footer": "Owsla ❤️ ⍫ Incident",
    "readyFooter": ["Owsla ❤️ ⍫ Incident", "⍫ Incident ❤️ Owsla"]
}

module.exports = settings;
